import pandas as pd
import re
from datetime import datetime

def clean_phone(phone):
    """
    Приводит телефон к формату +7XXXXXXXXXX
    Если телефон не распознан, возвращает 'нет телефона'
    """
    if pd.isna(phone):
        return 'нет телефона'
    
    # Удаляем всё, кроме цифр
    phone = re.sub(r'\D', '', str(phone))
    
    # Проверяем длину
    if len(phone) == 11 and phone.startswith('8'):
        phone = '7' + phone[1:]
    elif len(phone) == 10:
        phone = '7' + phone
    elif len(phone) == 11 and phone.startswith('7'):
        pass
    else:
        return 'нет телефона'
    
    return '+' + phone

def clean_date(date_str):
    """
    Приводит дату к формату ГГГГ-ММ-ДД
    Если дата не распознана, возвращает 'проблемная дата'
    """
    if pd.isna(date_str):
        return 'проблемная дата'
    
    try:
        # Пробуем распознать дату
        dt = pd.to_datetime(date_str, errors='coerce')
        if pd.isna(dt):
            return 'проблемная дата'
        return dt.strftime('%Y-%m-%d')
    except:
        return 'проблемная дата'

def clean_name(name):
    """
    Чистит имя: убирает лишние пробелы, делает с заглавной буквы
    """
    if pd.isna(name):
        return 'нет имени'
    
    name = ' '.join(str(name).split()).strip()
    return name.title()

def main(input_file='заявки.xlsx'):
    """
    Главная функция: читает файл, чистит, сохраняет результаты
    """
    # Читаем файл
    df = pd.read_excel(input_file)
    
    # Создаём копию для проблемных строк
    problem_rows = []
    
    # Применяем чистку
    df['Телефон_чистый'] = df['Телефон'].apply(clean_phone)
    df['Дата_чистая'] = df['Дата заявки'].apply(clean_date)
    df['Имя_чистое'] = df['Имя'].apply(clean_name)
    
    # Определяем проблемные строки
    df['проблема'] = (
        (df['Телефон_чистый'] == 'нет телефона') |
        (df['Дата_чистая'] == 'проблемная дата') |
        (df['Имя_чистое'] == 'нет имени')
    )
    
    # Чистые данные (без проблем)
    clean_df = df[~df['проблема']].copy()
    
    # Проблемные строки
    problem_df = df[df['проблема']].copy()
    
    # Убираем дубли по телефону (оставляем первую запись)
    clean_df = clean_df.drop_duplicates(subset=['Телефон_чистый'], keep='first')
    
    # Убираем вспомогательные колонки
    clean_df = clean_df[['Имя_чистое', 'Телефон_чистый', 'Дата_чистая', 'Источник']]
    clean_df.columns = ['Имя', 'Телефон', 'Дата заявки', 'Источник']
    
    problem_df = problem_df[['Имя', 'Телефон', 'Дата заявки', 'Источник', 'проблема']]
    
    # Сохраняем
    clean_df.to_excel('clean.xlsx', index=False)
    problem_df.to_excel('problems.xlsx', index=False)
    
    print(f"✅ Готово!")
    print(f"   - Чистых записей: {len(clean_df)}")
    print(f"   - Проблемных записей: {len(problem_df)}")
    print(f"   - Файлы сохранены: clean.xlsx и problems.xlsx")

if __name__ == "__main__":
    main()